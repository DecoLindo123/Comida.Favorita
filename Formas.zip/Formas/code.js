function quadrado() {
  penUp();
  moveTo(60, 300);
  penDown();
  penColor("red");
  penWidth(3);
  turnRight(90);
  moveForward(200);
  turnLeft(90);
  moveForward(200);
  turnLeft(90);
  moveForward(200);
  turnLeft(90);
  moveForward(200);
}
function triangulo() {
  penUp();
  moveTo(60, 250);
  penDown();
  penWidth(3);
  penColor("red");
  turnRight(90);
  moveForward(200);
  turnLeft(120);
  moveForward(200);
  turnLeft(120);
  moveForward(200);
}
onEvent("Quadrado_butao", "click", function( ) {
  setScreen("screenquadrado");
  quadrado();
});
onEvent("Triangulo_butao", "click", function( ) {
  setScreen("screentriangulo");
  triangulo();
});
function quad_area() {
  return (getNumber("text_input2") * getNumber("text_input2"));
}
function quad_perimetro() {
  return (getNumber("text_input2") * 4);
}
function tri_area() {
  return (getNumber("text_input5") * (getNumber("text_input1") / 2));
}
onEvent("text_input1", "input", function( ) {
  setText("text_input6", "A area do triangulo é: " + tri_area());
});
onEvent("text_input2", "input", function( ) {
  setText("text_input3", "O perimetro do quadrado é: " + quad_perimetro());
});
onEvent("text_input2", "input", function( ) {
  setText("text_input4", "A area do quadrado é: " + quad_area());
});
